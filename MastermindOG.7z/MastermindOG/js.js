let szinek = ['cyan', 'darkgreen', 'yellow', 'blue', 'red', 'pink', 'orange', 'purple']
let szamlalo = 0;
document.getElementById("game").innerHTML += `
<ul>
<li><button id="idBar" type="button">Bezár</button></li>
<li><button id="idBar" type="button">Kicsinyít</button></li>
<li><button id="idBar" type="button">Nagyít</button></li>
</ul>`
for (let index = 0; index < 10; index++) {
    if (index >= 2) {
        document.getElementById("game").innerHTML += `
        <div id="egySor">
        <div id="karikak">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
        </div>
        <div id="bogyokEgy">
            <span id="megNemTesztelt" class="picikek"></span>
            <br>
            <span id="megNemTesztelt" class="picikek"></span>
        </div>
        <div id="bogyokKetto">
            <span id="megNemTesztelt" class="picikek"></span>
            <br>
            <span id="megNemTesztelt" class="picikek"></span>
        </div>
        <div style="background: ${szinek[index - 2]};" onclick="Kattint(event)" id="rectangle"></div>
        </div>`
    }

    else{
        document.getElementById("game").innerHTML += `
        <div id="egySor">
        <div id="karikak">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
        </div>
        <div id="bogyokEgy">
            <span id="megNemTesztelt" class="picikek"></span>
            <br>
            <span id="megNemTesztelt" class="picikek"></span>
        </div>
        <div id="bogyokKetto">
            <span id="megNemTesztelt" class="picikek"></span>
            <br>
            <span id="megNemTesztelt" class="picikek"></span>
        </div>
        </div>`
    }


}
let nyertesSzinek = [szinek[Math.floor(Math.random()*szinek.length)],
szinek[Math.floor(Math.random()*szinek.length)],
szinek[Math.floor(Math.random()*szinek.length)],
szinek[Math.floor(Math.random()*szinek.length)]]
console.log(nyertesSzinek)

function Kattint(event){
    let piciSzamlalo =0;
    let szin =  event.target.style.backgroundColor;
    let feketek = document.querySelectorAll("span[class='dot']");
    feketek[szamlalo].style.backgroundColor = szin;
    szamlalo++;
    if (szamlalo % 4 == 0) {
        let nemFeketek = [];
        feketek.forEach(x => {
            if (x.style.backgroundColor != "" && x.value != "marEllenorzott") {
                x.value = "marEllenorzott"
                nemFeketek.push(x);
            }
        })
        nemFeketek.forEach(x => console.log(x.style.backgroundColor))
        let piciCuccok = document.querySelectorAll("span[id='megNemTesztelt']");
        console.log(piciCuccok.length)
        for (let index = 0; index < nemFeketek.length; index++) {
            piciCuccok[index].id = "";
            if (nyertesSzinek[index] == nemFeketek[index].style.backgroundColor) {
                piciCuccok[index].style.backgroundColor = "black";
                piciSzamlalo++;
            }
            else if(nyertesSzinek.includes(nemFeketek[index].style.backgroundColor)){
                piciCuccok[index].style.backgroundColor = "white";
            }
        
        }
        if (piciSzamlalo == 4) {
            let teglalapok = document.querySelectorAll("div[id='rectangle']")
            teglalapok.forEach(x => x.onclick = "")
            alert("Ügyi vagy! :(")
        }
    }
}



let gombokCucc = document.createElement("div");
gombokCucc.id = "gombok";
gombokCucc.innerHTML += `<button type="button" id="btnScore" style="width: 150px; height: 50px;">Score</button>`
gombokCucc.innerHTML += `<button type="button" id="btnUndo" style="width: 150px; height: 50px;">Undo</button>`
document.getElementById("game").appendChild(gombokCucc);